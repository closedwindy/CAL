#include "ctype.h"
#include "stdlib.h"
#include "stdio.h"



double cal(const char*& p) {
    double nums[100];
    int nums_size = 0;
    char ops[100];
    int ops_size = 0;

    while (*p && *p != ')') {
        if (isdigit(*p) || *p == '.') {
            char* end;
            double temp = strtod(p, &end);
            nums[nums_size++] = temp;
            p = end;
        } else if (*p == '(') {
            ++p;
            double temp = cal(p);
            nums[nums_size++] = temp;
            ++p; // Skip ')'
        } else if (*p == '+' || *p == '-' || *p == '*' || *p == '/') {
            ops[ops_size++] = *p;
            ++p;
        } else {
            ++p;
        }
    }


    int i = 0;
    while (i < ops_size) {
        if (ops[i] == '*' || ops[i] == '/') {
            double a = nums[i];
            double b = nums[i + 1];
            double res = (ops[i] == '*') ? a * b : a / b;
            nums[i] = res;


            for (int j = i + 1; j < nums_size - 1; ++j)
                nums[j] = nums[j + 1];
            nums_size--;

            for (int j = i; j < ops_size - 1; ++j)
                ops[j] = ops[j + 1];
            ops_size--;
        } else {
            ++i;
        }
    }

    double result = nums[0];
    for (int j = 0; j < ops_size; ++j) {
        if (ops[j] == '+')
            result += nums[j + 1];
        else
            result -= nums[j + 1];
    }

    return result;
}

double result(const char* expr) {
    const char* p = expr;
    return cal(p);
}
char expr[100];



int expr_pos = 0;

void Get_Expression(char a) {
    if (expr_pos < 99) {
        expr[expr_pos++] = a;
        expr[expr_pos] = '\0';
    }
}