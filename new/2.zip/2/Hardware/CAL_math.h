#ifndef __CAL_MATH_H
#define __CAL_MATH_H

void Get_Expression(char a);
double result(const char* expr);
#endif