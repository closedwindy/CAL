#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Encoder.h"
#include "Key.h"
#include "CAL_math.h"
int16_t Num;
uint8_t KeyNum;
uint8_t Count = 1;	


char allowed_chars[] = {'0','1','2','3','4','5','6','7','8','9','+','-','*','/','(',')','='}; 
int main(void)
{
	OLED_Init();
	Encoder_Init();
	Key_Init();
	while (1)
	{
		KeyNum = Key_GetNum();
		Num += Encoder_Get();
		if(Num>16||Num<0)
		{
			Num = 0;
		}
			if(KeyNum == 3)
				{
					Count++;
				}
				Get_Expression(allowed_chars[Num]);
			OLED_ShowChar(1,Count,allowed_chars[Num]);
			

	}
}
